import React from 'react';
import Room from '../components/Room';

function RoomView() {
  return <Room />
}

export default RoomView;