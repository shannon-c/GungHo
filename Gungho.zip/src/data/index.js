import posesImages from './posesImages';

export default {
  posesImages
}