import Room from './Room';

export default Room;