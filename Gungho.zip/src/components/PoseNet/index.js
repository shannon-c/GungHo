import PoseNet from "./PoseNet";

export default PoseNet;