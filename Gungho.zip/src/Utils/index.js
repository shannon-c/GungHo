import socket from './socket.io';

export default {
  socket,
};